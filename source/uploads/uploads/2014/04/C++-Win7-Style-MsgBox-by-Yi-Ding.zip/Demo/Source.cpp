// Vassile's Win7-Style Message Box Demonstration

#include <iostream>
#include "MessageBox-7.h"

using std::wcout; using std::endl;

int main()
{
	try
	{
		SetConsoleTitle( L"MessageBox-7 by Vassile" );

		wcout << L"Welcome to Vassile's MessageBox-7 Demonstration." << endl << endl;

		wcout << endl << L"[SHOWING] MessageBox 1" << endl;
		Win7MsgBox( L"MessageBox-7 by Vassile", L"A Welcome Message", L"I'm Yi Ding (Vassile).\nIt's glad to see you interested in my work.\nHave fun playing with MessageBox-7.", NULL );

		wcout << endl << L"[SHOWING] MessageBox 2" << endl;
		Win7MsgBox( L"-> Window Title <-", L"This is Message Abstarct.", L"Here goes Message Details...", WARNING7, L"A WARNING7 sign is used in this message box." );

		wcout << endl << L"[SHOWING] AskBox 1" << endl;
		wcout << L"Feedback: " << Win7AskBox( L"Ask Me Anything", L"Use AskBox to Get Simple Answers", L"You can prompt user...\nDo you love me?" ) << endl;

		wcout << endl << L"[SHOWING] AskBox 2" << endl;
		wcout << L"Feedback: " << Win7AskBox( L"Ask Me to Try Again",
											  L"AskBox Also Supports Retry/Cancel",
											  L"When Yes/No does not suit, Retry/Cancel may be helpful.", true, SECURITY7,
											  L"A SECURITY7 icon is used in this message box." ) << endl;
		
		wcout << endl << L"[SHOWING] AskBox 3" << endl;
		TASKDIALOG_BUTTON Buttons[] =
		{
			{ 1024, L"1024\nClick this button to play 1024." },
			{ 2048, L"2048\nClick this button to play 2048." },
			{ 4096, L"4096\nDoes this game exist?" }
		};
		wcout << L"Feedback: " << Win7AskBoxEx( L"1024/2048/4096?", L"AskBox Can Do Even More...", L"Sometimes two-way selection is not enough...\nLike this game selector:",
												Buttons, _countof( Buttons ), 2048, NULL ) << endl;

		wcout << endl << L"[SHOWING] AskBox 4" << endl;
		TASKDIALOG_BUTTON RadioButtons[]=
		{
			{ 1024, L"1024" },
			{ 2048, L"2048" },
			{ 4096, L"4096?" }
		};
		wcout << L"Feedback: " << Win7AskBoxR( L"1024/2048/4096?", L"Radio Buttons!",
											   L"Same? Not technically...\nRadio button seletor can have NO DEFAULT!\nYou'll get -1 if user selected nothing.",
											   RadioButtons, _countof( RadioButtons ), 0, INFO7, L"You can add hidden information in all MessageBox-7 windows." ) << endl;

		wcout << endl << L"[SHOWING] CheckBox 1" << endl;
		wcout << L"Feedback: " << Win7ChkBox( L"MessageBox-7 CheckBox", L"Tick It!",
											  L"Noticed the little CheckBox in the bottom left corner?\nClick on to check it out.", L"<- Tick me here" ) << endl;

		wcout << endl << L"[SHOWING] CheckBox 2" << endl;
		int Click;
		bool Check;
		Win7ChkBoxEx( Click, Check,
					  L"Advanced CheckBox", L"Check & Click", L"CheckBox can also have customized buttons.",
					  Buttons, _countof( Buttons ), 2048, L"Remember my choice", true, INFO7 );
		wcout << L"Button feedback: " << Click;
		wcout << endl << L"Checkbox feedback: " << Check << endl;

		wcout << endl << L"[SHOWING] CheckBox 3" << endl;
		Win7ChkBoxR( Click, Check,
					 L"Advanced CheckBox", L"Check & Click", L"Radio buttons are now back!\nAnd additional information...", L"Remember my choice",
					 RadioButtons, _countof( RadioButtons ), 4096, false, WARNING7, L"See?" );
		wcout << L"Button feedback: " << Click;
		wcout << endl << L"Checkbox feedback: " << Check << endl;

		wcout << endl << L"[SHOWING] ErrorBox" << endl;
		Win7ErrBox( L"Ready to Exit", L"You're about to leave this program!", L"ErrorBox will throw out an error code and cause program to exit.\n\nGoodbye!\nHope you like all these cute boxes." );

		return 0;
	}
	catch ( int ErrorCode ) { return ErrorCode; }
}